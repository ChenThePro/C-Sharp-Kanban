# Kanban
Instructions: 
* Replace "ID1_ID2_ID3" with the correct ID numbers
* Replace the "00" number at the end with your group's number


## Group members
329191555_214978322_212633895

## Group number (from Moodle)
21
